# 四柱推命の命式を出すプログラム（改良版）

## 使い方

```
$ make install
$ make up
$ make BIRTH='1978-09-26 13:51' SEX=0
```

